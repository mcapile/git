#!/bin/bash
version="1.0.20"
 
echo "Fazendo o pull da imagem"
sudo docker pull f4ward-docker-local.jfrog.io/fourward-inversare-transaction-mastercom-microservice:${version}
 
echo "Parando imagem existente"
sudo docker stop fourward-inversare-transaction-mastercom-microservice
 
echo "Removendo imagem existente"
sudo docker rm fourward-inversare-transaction-mastercom-microservice
 
echo "subindo nova imagem"
 
SERVER_PORT="9401"
EUREKA_BASE_URL="http://localhost:8761"
MASTERCARD_API_CONSUMER_KEY="4myCynaiT3GHX6Pf6Gc3CcAMLQr7QQAR6jnFgB9daba75148!d3164ef3606b49688daa10a5fdf7e3690000000000000000"
MASTERCARD_API_KEY_ALIAS="keyalias" 
MASTERCARD_API_KEY_PASSWORD="keystorepassword"
MASTERCARD_API_MASTERCARD_AUTH_FILE_PATH="/tmp/certificates/InversareEmissor-sandbox.p12" 
MASTERCARD_API_MASTERCARD_UAT_ENVIRONMENT_NAME="sandbox" 
MASTERCARD_API_IS_PRODUCTION=false
LOGGING_FILE="/tmp/transaction-mastercom-log.txt" 
TZ="America/Sao_Paulo"
JAVA_NET_USESYSTEMPROXIES=true
 
sudo docker run -p 9401:9401 --log-opt max-size=1g -v /app/Inversari-02-09/inversare_v1.2/app/inversare/certificates:/tmp/certificates --name fourward-inversare-transaction-mastercom-microservice --net=host -e http_proxy=http://192.168.124.10:3128 -e https_proxy=http://192.168.124.10:3128 -e HTTP_PROXY=http://192.168.124.10:3128 -e HTTPS_PROXY=http://192.168.124.10:3128 -e SERVER_PORT=${SERVER_PORT} -e EUREKA_BASE_URL=${EUREKA_BASE_URL} -e MASTERCARD_API_CONSUMER_KEY=${MASTERCARD_API_CONSUMER_KEY} -e MASTERCARD_API_KEY_ALIAS=${MASTERCARD_API_KEY_ALIAS} -e MASTERCARD_API_KEY_PASSWORD=${MASTERCARD_API_KEY_PASSWORD} -e MASTERCARD_API_MASTERCARD_AUTH_FILE_PATH=${MASTERCARD_API_MASTERCARD_AUTH_FILE_PATH} -e MASTERCARD_API_MASTERCARD_UAT_ENVIRONMENT_NAME=${MASTERCARD_API_MASTERCARD_UAT_ENVIRONMENT_NAME} -e MASTERCARD_API_IS_PRODUCTION=${MASTERCARD_API_IS_PRODUCTION} -e LOGGING_FILE=${LOGGING_FILE} -e TZ=${TZ} -d f4ward-docker-local.jfrog.io/fourward-inversare-transaction-mastercom-microservice:${version}