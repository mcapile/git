#!/bin/bash
version="1.1.3"

echo "Fazendo o pull da imagem"
sudo docker pull f4ward-docker-local.jfrog.io/fourward-inversare-queue-mastercom-microservice:${version}

echo "Parando imagem existente"
sudo docker stop fourward-inversare-queue-mastercom-microservice

echo "Removendo imagem existente"
sudo docker rm fourward-inversare-queue-mastercom-microservice

echo "subindo nova imagem"

SERVER_PORT="9500"
EUREKA_BASE_URL="http://localhost:8761"
MASTERCARD_API_CONSUMER_KEY="4myCynaiT3GHX6Pf6Gc3CcAMLQr7QQAR6jnFgB9daba75148!d3164ef3606b49688daa10a5fdf7e3690000000000000000"
MASTERCARD_API_KEY_ALIAS="keyalias" 
MASTERCARD_API_KEY_PASSWORD="keystorepassword" 
MASTERCARD_API_MASTERCARD_AUTH_FILE_PATH="/tmp/certificates/InversareEmissor-sandbox.p12"
MASTERCARD_API_MASTERCARD_UAT_ENVIRONMENT_NAME="sandbox"
MASTERCARD_API_IS_PRODUCTION=false
LOGGING_FILE="/tmp/log/queue-mastercom.txt" 
 
TZ="America/Sao_Paulo"

sudo docker run -p 9500:9500 --log-opt max-size=1g -v /opt/app/inversare/certificates:/tmp/certificates -v /opt/app/inversare/log:/tmp/log --name fourward-inversare-queue-mastercom-microservice --network="host" -e SERVER_PORT=${SERVER_PORT} -e EUREKA_BASE_URL=${EUREKA_BASE_URL} -e MASTERCARD_API_CONSUMER_KEY=${MASTERCARD_API_CONSUMER_KEY} -e MASTERCARD_API_KEY_ALIAS=${MASTERCARD_API_KEY_ALIAS} -e MASTERCARD_API_KEY_PASSWORD=${MASTERCARD_API_KEY_PASSWORD} -e MASTERCARD_API_MASTERCARD_AUTH_FILE_PATH=${MASTERCARD_API_MASTERCARD_AUTH_FILE_PATH} -e MASTERCARD_API_MASTERCARD_UAT_ENVIRONMENT_NAME=${MASTERCARD_API_MASTERCARD_UAT_ENVIRONMENT_NAME} -e MASTERCARD_API_IS_PRODUCTION=${MASTERCARD_API_IS_PRODUCTION} -e LOGGING_FILE=${LOGGING_FILE} -e TZ=${TZ} -d f4ward-docker-local.jfrog.io/fourward-inversare-queue-mastercom-microservice:${version}
