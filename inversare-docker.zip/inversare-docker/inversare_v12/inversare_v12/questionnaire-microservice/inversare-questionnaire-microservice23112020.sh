#!/bin/bash
version="1.6.4"

echo "Fazendo o pull da imagem"
sudo docker pull f4ward-docker-local.jfrog.io/fourward-inversare-questionnaire-microservice:${version}

echo "Parando imagem existente"
sudo docker stop fourward-inversare-questionnaire-microservice

echo "Removendo imagem existente"
sudo docker rm fourward-inversare-questionnaire-microservice

echo "subindo nova imagem"

SERVER_PORT="9099"
EUREKA_BASE_URL="http://localhost:8761"
SPRING_PROFILES_ACTIVE="mssql"
DATABASE_USERNAME="SVC_Inversare_Homol_SQL"
DATABASE_URL="BRSMCBCUVWHSC01:1433"
DATABASE_PASSWORD="#EDC2wsx1qaz"
DATABASE_NAME="SINV_INVERSARE"
MASTERCARD_API_CONSUMER_KEY="4myCynaiT3GHX6Pf6Gc3CcAMLQr7QQAR6jnFgB9daba75148!d3164ef3606b49688daa10a5fdf7e3690000000000000000"
MASTERCARD_API_KEY_ALIAS="keyalias"
MASTERCARD_API_KEY_PASSWORD="keystorepassword"
MASTERCARD_API_MASTERCARD_AUTH_FILE_PATH="/tmp/certificates/InversareEmissor-sandbox.p12"
MASTERCARD_API_MASTERCARD_UAT_ENVIRONMENT_NAME="sandbox"
MASTERCARD_API_IS_PRODUCTION=false
TZ="America/Sao_Paulo"

sudo docker run -p 9099:9099 --log-opt max-size=2g -v /opt/app/inversare/certificates:/tmp/certificates --name fourward-inversare-questionnaire-microservice --network="host" -e SERVER_PORT=${SERVER_PORT} -e EUREKA_BASE_URL=${EUREKA_BASE_URL} -e SPRING_PROFILES_ACTIVE=${SPRING_PROFILES_ACTIVE} -e DATABASE_USERNAME=${DATABASE_USERNAME} -e DATABASE_URL=${DATABASE_URL} -e DATABASE_PASSWORD=${DATABASE_PASSWORD} -e DATABASE_NAME=${DATABASE_NAME} -e MASTERCARD_API_CONSUMER_KEY=${MASTERCARD_API_CONSUMER_KEY} -e MASTERCARD_API_KEY_ALIAS=${MASTERCARD_API_KEY_ALIAS} -e MASTERCARD_API_KEY_PASSWORD=${MASTERCARD_API_KEY_PASSWORD} -e MASTERCARD_API_MASTERCARD_AUTH_FILE_PATH=${MASTERCARD_API_MASTERCARD_AUTH_FILE_PATH} -e MASTERCARD_API_MASTERCARD_UAT_ENVIRONMENT_NAME=${MASTERCARD_API_MASTERCARD_UAT_ENVIRONMENT_NAME} -e MASTERCARD_API_IS_PRODUCTION=${MASTERCARD_API_IS_PRODUCTION} -e TZ=${TZ} -d f4ward-docker-local.jfrog.io/fourward-inversare-questionnaire-microservice:${version}
