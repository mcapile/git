#!/bin/bash
version="1.0.6"

echo "Fazendo o pull da imagem"
sudo docker pull f4ward-docker-local.jfrog.io/fourward-inversare-parameters-microservice:${version}

echo "Parando imagem existente"
sudo docker stop fourward-inversare-parameters-microservice

echo "Removendo imagem existente"
sudo docker rm fourward-inversare-parameters-microservice

echo "subindo nova imagem"

SERVER_PORT="9091"
EUREKA_BASE_URL="http://localhost:8761"
EUREKA_CLIENT_ENABLED="true"
EUREKA_REGISTRATION_ENABLED="true"
EUREKA_CLIENT_REGISTER_WITH_EUREKA="true"
SPRING_PROFILES_ACTIVE="mssql"
DATABASE_USERNAME="SVC_Inversare_Homol_SQL"
DATABASE_URL="BRSMCBCUVWHSC01:1433"
DATABASE_PASSWORD="#EDC2wsx1qaz"
DATABASE_NAME="SINV_INVERSARE"
TZ="America/Sao_Paulo"

sudo docker run -p 9091:9091 --log-opt max-size=1g --name fourward-inversare-parameters-microservice --network="host" -e SERVER_PORT=${SERVER_PORT} -e EUREKA_BASE_URL=${EUREKA_BASE_URL} -e EUREKA_CLIENT_ENABLED=${EUREKA_CLIENT_ENABLED} -e EUREKA_REGISTRATION_ENABLED=${EUREKA_REGISTRATION_ENABLED} -e EUREKA_CLIENT_REGISTER_WITH_EUREKA=${EUREKA_CLIENT_REGISTER_WITH_EUREKA} -e SPRING_PROFILES_ACTIVE=${SPRING_PROFILES_ACTIVE} -e DATABASE_USERNAME=${DATABASE_USERNAME} -e DATABASE_URL=${DATABASE_URL} -e DATABASE_PASSWORD=${DATABASE_PASSWORD} -e DATABASE_NAME=${DATABASE_NAME} -e TZ=${TZ} -d f4ward-docker-local.jfrog.io/fourward-inversare-parameters-microservice:${version}
