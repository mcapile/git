#!/bin/bash

version="1.0.9"

echo "Fazendo o pull da imagem"
sudo docker pull f4ward-docker-local.jfrog.io/fourward-inversare-brand-transaction-microservice:${version}

echo "Parando imagem existente"
sudo docker stop fourward-inversare-brand-transaction-microservice

echo "Removendo imagem existente"
sudo docker rm fourward-inversare-brand-transaction-microservice

echo "subindo nova imagem"

SERVER_PORT=9400
EUREKA_BASE_URL=http://localhost:8761
INVERSARE_TRANSACTION_MASTERCARD_API_URL=http://localhost:9401
INVERSARE_TRANSACTION_VISA_API_URL=http://localhost:9402
TZ="America/Sao_Paulo"

sudo docker run -p 9400:9400 --log-opt max-size=1g --name fourward-inversare-brand-transaction-microservice --network="host" -e http_proxy=http://192.168.124.10:3128 -e https_proxy=http://192.168.124.10:3128 -e SERVER_PORT=${SERVER_PORT} -e EUREKA_BASE_URL=${EUREKA_BASE_URL} -e INVERSARE_TRANSACTION_MASTERCARD_API_URL=${INVERSARE_TRANSACTION_MASTERCARD_API_URL} -e INVERSARE_TRANSACTION_VISA_API_URL=${INVERSARE_TRANSACTION_VISA_API_URL} -e TZ=${TZ} -d f4ward-docker-local.jfrog.io/fourward-inversare-brand-transaction-microservice:${version}
