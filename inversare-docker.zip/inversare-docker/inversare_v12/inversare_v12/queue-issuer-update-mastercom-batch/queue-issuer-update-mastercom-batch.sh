#!/bin/bash
version="1.7.2"

echo "Fazendo o pull da imagem"
sudo docker pull f4ward-docker-local.jfrog.io/fourward-inversare-queue-issuer-update-mastercom-batch:${version}

echo "Parando imagem existente"
sudo docker stop fourward-inversare-queue-issuer-update-mastercom-batch

echo "Removendo imagem existente"
sudo docker rm fourward-inversare-queue-issuer-update-mastercom-batch

echo "subindo nova imagem"

SERVER_PORT="9090"
SPRING_PROFILES_ACTIVE="mssql"
DATABASE_USERNAME="SVC_Inversare_Homol_SQL"
DATABASE_URL="BRSMCBCUVWHSC01:1433"
DATABASE_PASSWORD="#EDC2wsx1qaz"
DATABASE_NAME="SINV_INVERSARE"
LOGGING_FILE="/tmp/log/queue-mastercom-batch.txt"
INVERSARE_API_QUEUE_MASTERCOM_BASE_URL="http://localhost:8081/api/v1/queue/queue-mastercard"
INVERSARE_API_QUEUE_MASTERCOM_CONNECTION_TIMEOUT="300000"
INVERSARE_API_CHARGEBACK_BASE_URL="http://localhost:8081/api/v1/chargeback"
INVERSARE_API_CHARGEBACK_CONNECTION_TIMEOUT="30000"
CRON_CONSUMER="60000"
DAYS_BEFORE_QUANTITY_SEARCH_QUEUE="90"

TZ="America/Sao_Paulo"

sudo docker run -p 9090:9090 --log-opt max-size=1g -v /opt/app/inversare/inversare/log:/tmp/log --name fourward-inversare-queue-issuer-update-mastercom-batch --network="host" -e SERVER_PORT=${SERVER_PORT} -e SPRING_PROFILES_ACTIVE=${SPRING_PROFILES_ACTIVE} -e DATABASE_USERNAME=${DATABASE_USERNAME} -e DATABASE_URL=${DATABASE_URL} -e DATABASE_PASSWORD=${DATABASE_PASSWORD} -e DATABASE_NAME=${DATABASE_NAME} -e LOGGING_FILE=${LOGGING_FILE} -e INVERSARE_API_QUEUE_MASTERCOM_BASE_URL=${INVERSARE_API_QUEUE_MASTERCOM_BASE_URL} -e INVERSARE_API_QUEUE_MASTERCOM_CONNECTION_TIMEOUT=${INVERSARE_API_QUEUE_MASTERCOM_CONNECTION_TIMEOUT} -e INVERSARE_API_CHARGEBACK_BASE_URL=${INVERSARE_API_CHARGEBACK_BASE_URL} -e INVERSARE_API_CHARGEBACK_CONNECTION_TIMEOUT=${INVERSARE_API_CHARGEBACK_CONNECTION_TIMEOUT} -e CRON_CONSUMER=${CRON_CONSUMER} -e DAYS_BEFORE_QUANTITY_SEARCH_QUEUE=${DAYS_BEFORE_QUANTITY_SEARCH_QUEUE} -e TZ=${TZ} -d f4ward-docker-local.jfrog.io/fourward-inversare-queue-issuer-update-mastercom-batch:${version}

