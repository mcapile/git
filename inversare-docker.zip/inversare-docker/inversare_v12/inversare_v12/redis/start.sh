sudo docker pull redis
sudo docker stop redis
sudo docker rm redis
docker run -p 6379:6379 --log-opt max-size=1g -m=3072M --network="host" --name redis -d redis