#!/bin/bash
version="1.1.5-DXC"

echo "Fazendo o pull da imagem"
sudo docker pull f4ward-docker-local.jfrog.io/fourward-inversare-queue-mastercom-microservice:${version}

echo "Parando imagem existente"
sudo docker stop fourward-inversare-queue-mastercom-microservice

echo "Removendo imagem existente"
sudo docker rm fourward-inversare-queue-mastercom-microservice

echo "subindo nova imagem"

SERVER_PORT="28026"
#SERVER_PORT="9500"
EUREKA_BASE_URL="http://localhost:28017"
#EUREKA_BASE_URL="http://localhost:8761"
#MASTERCARD_API_CONSUMER_KEY="kW3GrQe4_Zw5KU9f0FRXqeHYG1GzVYJkpI1oDVgd205f332a!57fb892498c2489998ecbab1bbc8cba40000000000000000"
MASTERCARD_API_CONSUMER_KEY="d4NX81dBqm5UYmZs7885tuPakC3yFnDDwP5sW8D-d1f5eb7a!3cc13173f67d4091a531947b75b3172e0000000000000000"
MASTERCARD_API_KEY_ALIAS="InversareAdq2"
#MASTERCARD_API_KEY_ALIAS="keyalias"
#MASTERCARD_API_KEY_PASSWORD="keystorepassword"
#MASTERCARD_API_KEY_PASSWORD="InversareAdq2"
MASTERCARD_API_KEY_PASSWORD="2AdqInversare"
#MASTERCARD_API_MASTERCARD_AUTH_FILE_PATH="/tmp/certificates/InversareAdq-sandbox.p12"
MASTERCARD_API_MASTERCARD_AUTH_FILE_PATH="/tmp/certificates/InversareAdq2-production.p12"
MASTERCARD_API_MASTERCARD_UAT_ENVIRONMENT_NAME="sandbox"
MASTERCARD_API_IS_PRODUCTION=true
LOGGING_FILE="/tmp/log/queue-mastercom.txt" 
 
TZ="America/Sao_Paulo"

sudo docker run -p $SERVER_PORT:$SERVER_PORT --log-opt max-size=1g -v /app/inversare_acquirer/certificates:/tmp/certificates -v /app/inversare_acquirer/log:/tmp/log --name fourward-inversare-queue-mastercom-microservice --network="host" -e SERVER_PORT=${SERVER_PORT} -e EUREKA_BASE_URL=${EUREKA_BASE_URL} -e MASTERCARD_API_CONSUMER_KEY=${MASTERCARD_API_CONSUMER_KEY} -e MASTERCARD_API_KEY_ALIAS=${MASTERCARD_API_KEY_ALIAS} -e MASTERCARD_API_KEY_PASSWORD=${MASTERCARD_API_KEY_PASSWORD} -e MASTERCARD_API_MASTERCARD_AUTH_FILE_PATH=${MASTERCARD_API_MASTERCARD_AUTH_FILE_PATH} -e MASTERCARD_API_MASTERCARD_UAT_ENVIRONMENT_NAME=${MASTERCARD_API_MASTERCARD_UAT_ENVIRONMENT_NAME} -e MASTERCARD_API_IS_PRODUCTION=${MASTERCARD_API_IS_PRODUCTION} -e LOGGING_FILE=${LOGGING_FILE} -e TZ=${TZ} -d f4ward-docker-local.jfrog.io/fourward-inversare-queue-mastercom-microservice:${version}

