#!/bin/bash

version="DXC-PROD.0.0.17"

sudo docker pull f4ward-docker-local.jfrog.io/fourward-inversare-front-end-acquirer:${version}
sudo docker stop inversare-acquirer-front
sudo docker rm inversare-acquirer-front
#sudo docker network create -d bridge inversare-network
#sudo docker run -d -p 4202:80 --log-opt max-size=1g --name inversare-acquirer-front --network=inversare-network f4ward-docker-local.jfrog.io/fourward-inversare-front-end-acquirer:${version}
#sudo docker run -d -p 28015:80 --log-opt max-size=1g --name inversare-acquirer-front f4ward-docker-local.jfrog.io/fourward-inversare-front-end-acquirer:${version}
#sudo docker run -d -p 28015:80 --log-opt max-size=1g --name inversare-acquirer-front f4ward-docker-local.jfrog.io/fourward-inversare-front-end-acquirer:${version}
sudo docker run -d -p 28015:80 --log-opt max-size=1g --name inversare-acquirer-front  f4ward-docker-local.jfrog.io/fourward-inversare-front-end-acquirer:${version}
