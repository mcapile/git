#!/bin/bash
version="1.1.0"

echo "Fazendo o pull da imagem"
sudo docker pull f4ward-docker-local.jfrog.io/fourward-inversare-queue-acquirer-mastercom-batch:${version}

echo "Parando imagem existente"
sudo docker stop fourward-inversare-queue-acquirer-mastercom-batch

echo "Removendo imagem existente"
sudo docker rm fourward-inversare-queue-acquirer-mastercom-batch

echo "subindo nova imagem"

#SERVER_PORT="9599"
SERVER_PORT="28028"
SPRING_PROFILES_ACTIVE="mssql"
#DATABASE_URL="fourward-inv-dev1.cspnscdipqkg.us-west-2.rds.amazonaws.com:1433"
DATABASE_URL="BRSMCBCUVWPBD03:1433"
DATABASE_NAME="inversare_acquirer"
#DATABASE_NAME="inversare_acquirer"
DATABASE_USERNAME="SVC_Inversare_Prod_SQL"
#DATABASE_USERNAME="admin"
DATABASE_PASSWORD="#EDC2wsx1qaz"
#DATABASE_PASSWORD="ZFirD4w8vei05yoP1r"
QUEUE_MASTERCARD_ACQUIRER_IMPORT_TRANSACTIONS_CRON=600000
KAFKA_BOOTSTRAP_ADDRESS="localhost:9092"
INVERARE_CHARGEBACK_KAFKA_TOPIC="inversare_acquirer_chargeback"
#QUEUE_MASTERCOM_URL="http://localhost:9090/queue-mastercard"
QUEUE_MASTERCOM_URL="http://localhost:28026/queue-mastercard"
QUEUE_MASTERCOM_CONNECTION_TIMEOUT="12000000"
QUEUE_MASTERCARD_ACQUIRER_SEARCH_DAYS_BEFORE=5
TZ="America/Sao_Paulo"

sudo docker run -p ${SERVER_PORT}:${SERVER_PORT} --log-opt max-size=1g --name fourward-inversare-queue-acquirer-mastercom-batch --network="host" -e SERVER_PORT=${SERVER_PORT} -e SPRING_PROFILES_ACTIVE=${SPRING_PROFILES_ACTIVE} -e DATABASE_URL=${DATABASE_URL} -e DATABASE_NAME=${DATABASE_NAME} -e DATABASE_USERNAME=${DATABASE_USERNAME} -e DATABASE_PASSWORD=${DATABASE_PASSWORD} -e QUEUE_MASTERCARD_ACQUIRER_IMPORT_TRANSACTIONS_CRON=${QUEUE_MASTERCARD_ACQUIRER_IMPORT_TRANSACTIONS_CRON} -e KAFKA_BOOTSTRAP_ADDRESS=${KAFKA_BOOTSTRAP_ADDRESS} -e INVERARE_CHARGEBACK_KAFKA_TOPIC=${INVERARE_CHARGEBACK_KAFKA_TOPIC} -e QUEUE_MASTERCOM_URL=${QUEUE_MASTERCOM_URL} -e QUEUE_MASTERCOM_CONNECTION_TIMEOUT=${QUEUE_MASTERCOM_CONNECTION_TIMEOUT} -e QUEUE_MASTERCARD_ACQUIRER_SEARCH_DAYS_BEFORE=${QUEUE_MASTERCARD_ACQUIRER_SEARCH_DAYS_BEFORE} -e TZ=${TZ} -d f4ward-docker-local.jfrog.io/fourward-inversare-queue-acquirer-mastercom-batch:${version}
