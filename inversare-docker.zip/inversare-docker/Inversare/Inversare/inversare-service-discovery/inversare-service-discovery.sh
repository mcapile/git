#!/bin/bash

version="0.1.2"

echo "Fazendo o pull da imagem"
sudo docker pull f4ward-docker-local.jfrog.io/fourward-inversare-service-discovery-server:${version}

echo "Parando imagem existente"
sudo docker stop fourward-inversare-service-discovery-server 

echo "Removendo imagem existente"
sudo docker rm fourward-inversare-service-discovery-server

echo "subindo nova imagem"

SPRING_APPLICATION_NAME="fwd-acquirer-service-discovery-server"
#SERVER_PORT="8761"
SERVER_PORT="28017"
TZ="America/Sao_Paulo"
EUREKA_INSTANCE_HOSTNAME="localhost"

sudo docker run -p $SERVER_PORT:$SERVER_PORT --log-opt max-size=512M -m=512M --name fourward-inversare-service-discovery-server --network="host" -e SPRING_APPLICATION_NAME=${SPRING_APPLICATION_NAME} -e SERVER_PORT=${SERVER_PORT} -e EUREKA_INSTANCE_HOSTNAME=${EUREKA_INSTANCE_HOSTNAME} -e TZ=${TZ} -d f4ward-docker-local.jfrog.io/fourward-inversare-service-discovery-server:${version}
