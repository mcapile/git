#! /bin/bash
version="2.3.1"

echo "Fazendo o pull da imagem"
sudo docker pull f4ward-docker-local.jfrog.io/fourward-authenticator-management-microservice:${version}

echo "Parando imagem existente"
sudo docker stop fourward-authenticator-management-microservice

echo "Removendo imagem existente"
sudo docker rm fourward-authenticator-management-microservice

echo "subindo nova imagem"

DOCK_NET="host"
API_LOGGING_FILE="/tmp/fourward-authenticator-management-microservice.log"
FOURWARD_SERVICE_DISCOVERY="localhost:28017"
#FOURWARD_SERVICE_DISCOVERY="localhost:8761"
API_SERVER_PORT=28020
API_DATABASE_USERNAME="SVC_Inversare_Prod_SQL"
API_DATABASE_PASSWORD="#EDC2wsx1qaz"
API_DATABASE_URL="BRSMCBCUVWPBD03:1433"
API_DATABASE_NAME="inversare_acquirer_auth_management"
API_DATABASE_USE_SSL=false
#API_AUTH_SERVER_URL="http://localhost:9999/auth/uaa"
API_AUTH_SERVER_URL="http://localhost:28019/auth/uaa"
SPRING_PROFILES_ACTIVE="mssql"
#FLYWAY_ENABLED=true
FLYWAY_ENABLED=false
CORS_ACTIVE=false

sudo docker run -p ${API_SERVER_PORT}:${API_SERVER_PORT} --log-opt max-size=1g --name fourward-authenticator-management-microservice --network=${DOCK_NET} -e API_SERVER_PORT=${API_SERVER_PORT} -e API_LOGGING_FILE=${API_LOGGING_FILE} -e FOURWARD_SERVICE_DISCOVERY=${FOURWARD_SERVICE_DISCOVERY} -e API_DATABASE_USERNAME=${API_DATABASE_USERNAME} -e API_DATABASE_PASSWORD=${API_DATABASE_PASSWORD} -e API_DATABASE_URL=${API_DATABASE_URL} -e API_DATABASE_NAME=${API_DATABASE_NAME} -e API_DATABASE_USE_SSL=${API_DATABASE_USE_SSL} -e API_AUTH_SERVER_URL=${API_AUTH_SERVER_URL} -e SPRING_PROFILES_ACTIVE=${SPRING_PROFILES_ACTIVE} -e FLYWAY_ENABLED=${FLYWAY_ENABLED} -e CORS_ACTIVE=${CORS_ACTIVE} -d f4ward-docker-local.jfrog.io/fourward-authenticator-management-microservice:${version}
