#!/bin/bash
version="1.2.1"

echo "Fazendo o pull da imagem"
sudo docker pull f4ward-docker-local.jfrog.io/fourward-inversare-queue-acquirer-vrol-batch:${version}

echo "Parando imagem existente"
sudo docker stop fourward-inversare-queue-acquirer-vrol-batch

echo "Removendo imagem existente"
sudo docker rm fourward-inversare-queue-acquirer-vrol-batch

echo "subindo nova imagem"

#SERVER_PORT="9599"
SERVER_PORT="28024"
SPRING_PROFILES_ACTIVE="mssql"
DATABASE_URL="BRSMCBCUVWPBD03:1433"
DATABASE_NAME="inversare_acquirer"
DATABASE_USERNAME="SVC_Inversare_Prod_SQL"
DATABASE_PASSWORD="#EDC2wsx1qaz"
IMPORT_CHARGEBACKS_SCHEDULER_FIXED_DELAY=86400000
KAFKA_BOOTSTRAP_ADDRESS="localhost:9092"
INVERARE_CHARGEBACK_KAFKA_TOPIC="inversare_acquirer_chargeback"
#QUEUE_VISA_URL="http://localhost:9699/vrol/acquirer"
QUEUE_VISA_URL="http://localhost:28025/vrol/acquirer"
QUEUE_VISA_CONNECTION_TIMEOUT="12000000"
TZ="America/Sao_Paulo"

sudo docker run -p ${SERVER_PORT}:${SERVER_PORT} --log-opt max-size=1g --name fourward-inversare-queue-acquirer-vrol-batch --network="host" -e SERVER_PORT=${SERVER_PORT} -e SPRING_PROFILES_ACTIVE=${SPRING_PROFILES_ACTIVE} -e DATABASE_URL=${DATABASE_URL} -e DATABASE_NAME=${DATABASE_NAME} -e DATABASE_USERNAME=${DATABASE_USERNAME} -e DATABASE_PASSWORD=${DATABASE_PASSWORD} -e IMPORT_CHARGEBACKS_SCHEDULER_FIXED_DELAY=${IMPORT_CHARGEBACKS_SCHEDULER_FIXED_DELAY} -e KAFKA_BOOTSTRAP_ADDRESS=${KAFKA_BOOTSTRAP_ADDRESS} -e INVERARE_CHARGEBACK_KAFKA_TOPIC=${INVERARE_CHARGEBACK_KAFKA_TOPIC} -e QUEUE_VISA_URL=${QUEUE_VISA_URL} -e QUEUE_VISA_CONNECTION_TIMEOUT=${QUEUE_VISA_CONNECTION_TIMEOUT} -e TZ=${TZ} -d f4ward-docker-local.jfrog.io/fourward-inversare-queue-acquirer-vrol-batch:${version}
