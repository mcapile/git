#!/bin/bash
version="1.9.1"

echo "Fazendo o pull da imagem"
sudo docker pull f4ward-docker-local.jfrog.io/fourward-inversare-chargeback-vrol-microservice:${version}

echo "Parando imagem existente"
sudo docker stop fourward-inversare-chargeback-vrol-microservice

echo "Removendo imagem existente"
sudo docker rm fourward-inversare-chargeback-vrol-microservice

echo "subindo nova imagem"

SERVER_PORT="28019"
EUREKA_BASE_URL="http://localhost:28017/eureka/"
EUREKA_ENABLED=true
VISA_API_ROL_SI_URL="https://mutualcertservicesgateway.visa.com/rsrv_rolsi-mte2/api"
VISA_API_CONNECTION_TIMEOUT_LIMIT="120000"
VISA_API_CLIENT_KEY_STORE_PATH="/opt/files/certificates/xvmi34101c.pfx"
VISA_API_SSL_LOG_PATH="/opt/files/chargeback-vrol-ssl.log"
VISA_API_DEBUG_SSL=true
VISA_API_USE_CERTIFICATE=true
VISA_API_USERNAME="xvmi34101c"
VISA_API_PASSWORD="Brbglobal2020#"
VISA_API_CERTIFICATE_PASSWORD=""
FILE_PATH_VISA="/tmp/files"
VROL_MEMBER_ROLE="A"
VROL_USER_ID="xvmi34101c"
VROL_USER_TYPE="internalId"

TZ="America/Sao_Paulo"

sudo docker run -p $SERVER_PORT:$SERVER_PORT --log-opt max-size=1g -v /app/inversare_acquirer/certificates:/opt/files/certificates -v /app/inversare_acquirer/log:/opt/files --name fourward-inversare-chargeback-vrol-microservice --network="host" -e SERVER_PORT=${SERVER_PORT} -e EUREKA_BASE_URL=${EUREKA_BASE_URL} -e EUREKA_ENABLED=${EUREKA_ENABLED} -e VISA_API_ROL_SI_URL=${VISA_API_ROL_SI_URL} -e VISA_API_CONNECTION_TIMEOUT_LIMIT=${VISA_API_CONNECTION_TIMEOUT_LIMIT} -e VISA_API_CLIENT_KEY_STORE_PATH=${VISA_API_CLIENT_KEY_STORE_PATH} -e VISA_API_SSL_LOG_PATH=${VISA_API_SSL_LOG_PATH} -e VISA_API_DEBUG_SSL=${VISA_API_DEBUG_SSL} -e VISA_API_USE_CERTIFICATE=${VISA_API_USE_CERTIFICATE} -e VISA_API_USERNAME=${VISA_API_USERNAME} -e VISA_API_PASSWORD=${VISA_API_PASSWORD} -e VISA_API_CERTIFICATE_PASSWORD=${VISA_API_CERTIFICATE_PASSWORD} -e FILE_PATH_VISA=${FILE_PATH_VISA} -e VROL_MEMBER_ROLE=${VROL_MEMBER_ROLE} -e VROL_USER_ID=${VROL_USER_ID} -e VROL_USER_TYPE=${VROL_USER_TYPE} -e TZ=${TZ} -d f4ward-docker-local.jfrog.io/fourward-inversare-chargeback-vrol-microservice:${version}
